// 导入配置vuex的数据
import Vue from 'vue'
import Vuex from 'vuex'

import store1 from './data'

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        leftToggle: false,
        store1,
    },
    mutations: {
        /*
            如果在mutations和actions中，使用解构赋值获取state中的数据，那就只能动态获取，不能设置(设置的值不会响应到state中)。
            如果要设置，就接受state本身。
        */ 
        setLeftToggle: (state) => {
            state.leftToggle = !state.leftToggle;
        }
    },
    strict: true
});